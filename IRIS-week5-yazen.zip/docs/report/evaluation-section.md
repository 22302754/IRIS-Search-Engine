# Evaluation — Report Section

Author: Yazen (AI Engineer, Pre-processing & Ranking) · Requirement: NFR-7 (Precision@10 over 20 test queries)
Data: `docs/test-queries.json`, `docs/judging-sheet.csv` · Tools: `ranker/judging_sheet.py`, `ranker/judge_agreement.py`

> Values marked **[fill]** come from the commands named next to them. Fill them in after both judges have finished;
> do not change the method or the queries after seeing the results.

## Purpose

The unit and end-to-end tests show that IRIS computes what it is designed to compute. They do not show whether the
pages it puts first are the pages a user wants. This section measures that: for 20 realistic queries, people judged
whether each of the top 10 results answers the query, and the share of relevant results is reported as
Precision@10 (Manning et al., 2008, ch. 8).

## Method

**Test queries.** The 20 queries in `docs/test-queries.json` were written before any results were seen. They cover
all sites of the collection and mix short queries (*inverted index*), longer ones (*cosine similarity vector space
model*) and searches for one known page (*sapiens brief history of humankind*). Each query has a written rule,
*relevant if*, that says what a relevant page must contain, and at least one page in the collection that meets it
(checked with `python3 -m ranker.check_queries`). Three queries (Q12–Q14) were corrected or replaced on 1 November,
before any judging, because the collection had no page for them.

**Results judged.** `python3 -m ranker.judging_sheet` ran each query through `search_page()`, the function behind
the public search page, and saved the top 10 results in `docs/judging-sheet.csv` on **[fill: date]**. The sheet
therefore contains exactly what a user saw: only pages that contain every query word, ordered by cosine score plus
the title bonus.

**Judging.** Two team members, Yazen and Hani, judged every row independently, each on a copy of the sheet, without
seeing the other's answers. For each row the judge opened the page and wrote **1** if it meets the query's *relevant
if* rule and **0** otherwise, using only that rule — not the score, the rank or the site. A page that mentions the topic
only in passing (a reference list, a menu) was judged 0.

**Agreement.** `python3 -m ranker.judge_agreement` compared the two sheets row by row and reports the percent of
rows with the same label and Cohen's kappa (Cohen, 1960), which corrects that percentage for agreement expected by
chance. Kappa is read on the scale of Landis and Koch (1977): 0.41–0.60 moderate, 0.61–0.80 substantial, above
0.80 almost perfect. Rows on which the judges disagreed were discussed and given one agreed label in the final
sheet (`--merge`).

**Measures.** For each query

$$\text{Precision@10} = \frac{\text{relevant results among the top 10}}{10}$$

and the system score is the mean over the 20 queries. The divisor is always 10: a query that returns fewer than
10 results counts the empty positions as not relevant. Because the search page requires every query word, some
queries return fewer than 10 pages, so we also report the precision of the results actually returned
(relevant ÷ returned), which shows whether the shown results are good even when there are few of them.

## Results

### Agreement between the judges

| Measure | Value |
| --- | ---: |
| Rows judged by both | **[fill]** |
| Rows with the same label | **[fill]** (**[fill]** %) |
| Cohen's kappa | **[fill]** (**[fill]**: slight / fair / moderate / substantial / almost perfect) |
| Rows decided by discussion | **[fill]** |

Source: `python3 -m ranker.judge_agreement docs/judging-yazen.csv docs/judging-hani.csv --names Yazen,Hani --markdown`

### Precision@10 per query

| Query | Results returned | Relevant (agreed) | Precision@10 | Precision of returned |
| --- | ---: | ---: | ---: | ---: |
| Q01 inverted index | **[fill]** | **[fill]** | **[fill]** | **[fill]** |
| Q02 tf idf term weighting | | | | |
| Q03 cosine similarity vector space model | | | | |
| Q04 precision and recall | | | | |
| Q05 web crawler politeness robots | | | | |
| Q06 pagerank link analysis | | | | |
| Q07 stemming and lemmatization | | | | |
| Q08 python list comprehension | | | | |
| Q09 reading and writing files in python | | | | |
| Q10 handling exceptions try except | | | | |
| Q11 regular expressions | | | | |
| Q12 css flexbox layout | | | | |
| Q13 javascript click event listener | | | | |
| Q14 aria roles accessibility | | | | |
| Q15 create index b-tree postgresql | | | | |
| Q16 jsonb operators | | | | |
| Q17 scrapy item pipeline | | | | |
| Q18 flask blueprints | | | | |
| Q19 albert einstein quotes | | | | |
| Q20 sapiens brief history of humankind | | | | |
| **Mean** | | | **[fill]** | **[fill]** |

Source: `python3 -m ranker.judging_sheet --score docs/judging-sheet.csv` (it prints, per query, the relevant results
and the number judged, which is the number returned).

**Upper limits known before judging.** On 2 November the search page returned fewer than 10 pages for four queries
(ranking section, speed table): Q05 (5 pages), Q16 (5), Q19 (8) and Q20 (3). Their Precision@10 can be at most 0.5,
0.5, 0.8 and 0.3 even if every result is relevant, so the mean Precision@10 can be at most **0.905**. This is the
cost of requiring every query word, and the precision of the returned results is the fairer measure for these four.

## Discussion

Pick 3–4 queries from the table: at least one that worked well and at least one that worked badly. For each, say
what was ranked first and **why**, using the ranking-details page (`/explain`) to show tf, idf and the title bonus.

**[fill] — a query that worked well.** *Example of what to write:* “Q18 *flask blueprints* scored [fill]. Both words
are rare in the collection outside the Flask documentation, so their idf is high, and the page *Blueprints — Flask
Documentation* has both words in its title (bonus +0.1), which put it first.”

**[fill] — a query that worked badly.** *Things to check:* Was a long page ranked high because it uses a common query
word many times (raw tf)? Did a page match all words only in a reference list or a menu that the cleaner left in? Did
stemming merge different words (*university* / *universe*) or miss a match (*crawling* / *crawler*)?

**[fill] — a known-item query (Q19 or Q20).** Few results were returned; say whether the one page the user wanted
was first, and why the precision of the returned results is the better measure here.

**[fill] — a query with words from several sites (Q11 *regular expressions*).** Say whether results from the Python
documentation and from MDN were mixed, and whether the site filter would help a user.

## Limitations

- **Two judges, 20 queries, one collection.** The numbers describe this collection and these queries; they are a
  check of the system, not a general benchmark.
- **Recall is not measured.** It would require knowing every relevant page among 4,702, which was not possible.
- **Binary judgments.** A page is relevant or not; a graded scale (e.g. 0–2) would separate the best answer from an
  acceptable one.
- **One ranking version.** The sheet was made once. Comparing alternatives (logarithmic tf, BM25, another title
  bonus, no stemming) needs a new sheet per version; judgments of URLs that appear again can be reused.

## References

Cohen, J. (1960). A coefficient of agreement for nominal scales. *Educational and Psychological Measurement, 20*(1), 37–46.

Landis, J. R., & Koch, G. G. (1977). The measurement of observer agreement for categorical data. *Biometrics, 33*(1), 159–174.

Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to information retrieval*, ch. 8. Cambridge University Press.
