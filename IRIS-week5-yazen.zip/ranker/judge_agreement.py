"""
IRIS - compare the relevance judgments of two judges (Precision@10 evaluation, NFR-7).

Each judge fills in a COPY of the judging sheet on their own, without looking at the other's answers:

    python3 -m ranker.judging_sheet --out docs/judging-yazen.csv
    cp docs/judging-yazen.csv docs/judging-hani.csv          # the same rows for both judges

Then:

    python3 -m ranker.judge_agreement docs/judging-yazen.csv docs/judging-hani.csv
    python3 -m ranker.judge_agreement docs/judging-yazen.csv docs/judging-hani.csv --markdown   # tables for the report
    python3 -m ranker.judge_agreement docs/judging-yazen.csv docs/judging-hani.csv --merge docs/judging-sheet.csv

It prints, per query, both judges' Precision@10 and how often they agreed; overall percent agreement and
Cohen's kappa; and every row where they disagree, to be discussed. --merge writes the final sheet: rows where both
judges agree keep that label; rows where they disagree get an EMPTY `relevant` cell and `judge` = "DISAGREE ...",
so the team decides them together and then runs `python3 -m ranker.judging_sheet --score docs/judging-sheet.csv`.

Rows are matched by (query_id, page_id). Only rows judged 0 or 1 by both judges are compared.
"""
import argparse
import csv
import sys
from collections import OrderedDict


def read_sheet(path):
    """{(query_id, page_id): row} in file order."""
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = {"query_id", "page_id", "relevant"} - set(reader.fieldnames or [])
        if missing:
            sys.exit(f"{path}: missing column(s) {', '.join(sorted(missing))}")
        return OrderedDict(((row["query_id"], row["page_id"]), row) for row in reader)


def label(row):
    value = (row.get("relevant") or "").strip()
    return int(value) if value in ("0", "1") else None


def cohen_kappa(pairs):
    """Cohen's kappa for a list of (a, b) labels in {0, 1}. None when it is undefined."""
    n = len(pairs)
    if n == 0:
        return None
    observed = sum(a == b for a, b in pairs) / n
    a_yes = sum(a for a, _ in pairs) / n
    b_yes = sum(b for _, b in pairs) / n
    expected = a_yes * b_yes + (1 - a_yes) * (1 - b_yes)
    if expected == 1:
        return None                      # both judges gave one single label to everything
    return (observed - expected) / (1 - expected)


def interpret_kappa(kappa):
    """Landis & Koch (1977) scale."""
    if kappa is None:
        return "undefined"
    if kappa < 0:
        return "poor"
    for limit, words in ((0.20, "slight"), (0.40, "fair"), (0.60, "moderate"), (0.80, "substantial")):
        if kappa <= limit:
            return words
    return "almost perfect"


def compare(sheet_a, sheet_b):
    """Per-query and overall comparison of two judged sheets."""
    per_query = OrderedDict()
    pairs, disagreements = [], []
    for key, row_a in sheet_a.items():
        query_id = row_a["query_id"]
        entry = per_query.setdefault(query_id, {"query": row_a.get("query", ""), "hits_a": 0, "hits_b": 0,
                                                "both": 0, "agree": 0, "rows": 0})
        entry["rows"] += 1
        a = label(row_a)
        b = label(sheet_b[key]) if key in sheet_b else None
        entry["hits_a"] += a or 0
        entry["hits_b"] += b or 0
        if a is None or b is None:
            continue
        entry["both"] += 1
        entry["agree"] += a == b
        pairs.append((a, b))
        if a != b:
            disagreements.append({"query_id": query_id, "rank": row_a.get("rank", ""), "page_id": key[1],
                                  "title": row_a.get("title", ""), "url": row_a.get("url", ""), "a": a, "b": b})
    compared = len(pairs)
    agreed = sum(a == b for a, b in pairs)
    kappa = cohen_kappa(pairs)
    return {
        "per_query": per_query,
        "compared": compared,
        "agreed": agreed,
        "percent_agreement": agreed / compared if compared else None,
        "kappa": kappa,
        "kappa_words": interpret_kappa(kappa),
        "disagreements": disagreements,
        "only_in_b": [key for key in sheet_b if key not in sheet_a],
    }


def merge(sheet_a, sheet_b, out, name_a="A", name_b="B"):
    """Write the final sheet: agreed labels kept, disagreements left empty for the team to decide."""
    rows = []
    for key, row_a in sheet_a.items():
        row = dict(row_a)
        a = label(row_a)
        b = label(sheet_b[key]) if key in sheet_b else None
        if a is not None and a == b:
            row["relevant"], row["judge"] = str(a), f"{name_a}+{name_b}"
        else:
            row["relevant"] = ""
            row["judge"] = f"DISAGREE {name_a}={'' if a is None else a} {name_b}={'' if b is None else b}"
        rows.append(row)
    fields = list(next(iter(sheet_a.values())).keys()) if sheet_a else []
    with open(out, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return sum(1 for r in rows if not r["relevant"])


def _fmt(x, digits=2):
    return "–" if x is None else f"{x:.{digits}f}"


def report(result, name_a, name_b, markdown=False):
    lines = []
    if markdown:
        lines += [f"| Query | Judged by both | P@10 ({name_a}) | P@10 ({name_b}) | Agreement |",
                  "| --- | ---: | ---: | ---: | ---: |"]
        for qid, e in result["per_query"].items():
            agree = e["agree"] / e["both"] if e["both"] else None
            lines.append(f"| {qid} {e['query']} | {e['both']} | {e['hits_a'] / 10:.1f} | {e['hits_b'] / 10:.1f} | "
                         f"{'–' if agree is None else f'{agree:.0%}'} |")
        lines += ["", f"Rows judged by both: **{result['compared']}**. Percent agreement: "
                      f"**{_fmt(result['percent_agreement'] and result['percent_agreement'] * 100, 1)}%**. "
                      f"Cohen's kappa: **{_fmt(result['kappa'])}** ({result['kappa_words']})."]
    else:
        lines.append(f"{'Query':<44} both  P@10 {name_a:<6} P@10 {name_b:<6} agree")
        for qid, e in result["per_query"].items():
            agree = e["agree"] / e["both"] if e["both"] else None
            lines.append(f"{(qid + ' ' + e['query'])[:43]:<44} {e['both']:>4}  {e['hits_a'] / 10:>9.1f}  "
                         f"{e['hits_b'] / 10:>9.1f}  {'–' if agree is None else f'{agree:.0%}':>5}")
        pa = result["percent_agreement"]
        lines += ["", f"Rows judged by both judges: {result['compared']}",
                  f"Percent agreement: {'–' if pa is None else f'{pa:.1%}'}",
                  f"Cohen's kappa: {_fmt(result['kappa'], 3)} ({result['kappa_words']})"]
    if result["disagreements"]:
        lines += ["", f"Disagreements to discuss ({len(result['disagreements'])}):"]
        for d in result["disagreements"]:
            lines.append(f"  {d['query_id']} #{d['rank']}  {name_a}={d['a']} {name_b}={d['b']}  {d['title'][:50]}  {d['url']}")
    if result["only_in_b"]:
        lines += ["", f"Warning: {len(result['only_in_b'])} row(s) of the second sheet are not in the first one "
                      "(the sheets should be copies of the same file)."]
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Compare two judges' relevance judgments.")
    ap.add_argument("sheet_a")
    ap.add_argument("sheet_b")
    ap.add_argument("--names", default="A,B", help="short names of the two judges, e.g. Yazen,Hani")
    ap.add_argument("--markdown", action="store_true", help="print the tables in Markdown for the report")
    ap.add_argument("--merge", metavar="OUT", help="write the final sheet (agreed labels; disagreements left empty)")
    args = ap.parse_args(argv)
    name_a, name_b = (args.names.split(",") + ["B"])[:2]
    a, b = read_sheet(args.sheet_a), read_sheet(args.sheet_b)
    result = compare(a, b)
    print(report(result, name_a, name_b, markdown=args.markdown))
    if args.merge:
        open_rows = merge(a, b, args.merge, name_a, name_b)
        print(f"\nWrote {args.merge}: {open_rows} row(s) still to decide together "
              f"(empty 'relevant'), then run: python3 -m ranker.judging_sheet --score {args.merge}")
    return result


if __name__ == "__main__":
    main()
