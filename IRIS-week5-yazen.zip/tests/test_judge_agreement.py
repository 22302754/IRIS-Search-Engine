"""Tests for ranker/judge_agreement.py (comparing two judges for the Precision@10 evaluation)."""
import csv

import pytest

from ranker.judge_agreement import cohen_kappa, compare, interpret_kappa, main, merge, read_sheet

COLUMNS = ["query_id", "query", "rank", "page_id", "score", "site", "title", "url", "relevant_if", "relevant", "judge"]


def write_sheet(path, labels):
    """labels: {query_id: [label or "" for ranks 1..n]}"""
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS)
        w.writeheader()
        for qid, values in labels.items():
            for rank, value in enumerate(values, 1):
                w.writerow({"query_id": qid, "query": f"query {qid}", "rank": rank, "page_id": f"{qid}{rank}",
                            "score": "0.5", "site": "s", "title": f"T{rank}", "url": f"u/{qid}/{rank}",
                            "relevant_if": "rule", "relevant": value, "judge": ""})
    return path


def test_kappa_perfect_agreement_is_one():
    assert cohen_kappa([(1, 1), (0, 0), (1, 1), (0, 0)]) == pytest.approx(1.0)


def test_kappa_hand_calculated():
    # 10 pairs: both 1 = 4, both 0 = 3, A1/B0 = 2, A0/B1 = 1
    pairs = [(1, 1)] * 4 + [(0, 0)] * 3 + [(1, 0)] * 2 + [(0, 1)]
    # observed 0.7; A yes 0.6, B yes 0.5 -> expected 0.6*0.5 + 0.4*0.5 = 0.5; kappa = (0.7-0.5)/0.5 = 0.4
    assert cohen_kappa(pairs) == pytest.approx(0.4)
    assert interpret_kappa(0.4) == "fair"


def test_kappa_undefined_when_everything_has_one_label():
    assert cohen_kappa([(1, 1), (1, 1)]) is None
    assert cohen_kappa([]) is None


def test_compare_per_query_precision_and_disagreements(tmp_path):
    a = write_sheet(tmp_path / "a.csv", {"Q01": [1, 1, 0, 1], "Q02": [0, 0, 1]})
    b = write_sheet(tmp_path / "b.csv", {"Q01": [1, 0, 0, 1], "Q02": [0, 0, 1]})
    result = compare(read_sheet(a), read_sheet(b))
    q1 = result["per_query"]["Q01"]
    assert (q1["hits_a"], q1["hits_b"], q1["both"], q1["agree"]) == (3, 2, 4, 3)
    assert result["compared"] == 7 and result["agreed"] == 6
    assert result["percent_agreement"] == pytest.approx(6 / 7)
    assert [(d["query_id"], d["rank"], d["a"], d["b"]) for d in result["disagreements"]] == [("Q01", "2", 1, 0)]


def test_unjudged_rows_are_not_compared(tmp_path):
    a = write_sheet(tmp_path / "a.csv", {"Q01": [1, "", 0]})
    b = write_sheet(tmp_path / "b.csv", {"Q01": [1, 1, ""]})
    result = compare(read_sheet(a), read_sheet(b))
    assert result["compared"] == 1 and result["disagreements"] == []


def test_merge_keeps_agreed_labels_and_leaves_disagreements_empty(tmp_path):
    a = write_sheet(tmp_path / "a.csv", {"Q01": [1, 1, 0]})
    b = write_sheet(tmp_path / "b.csv", {"Q01": [1, 0, 0]})
    out = tmp_path / "final.csv"
    assert merge(read_sheet(a), read_sheet(b), out, "Yazen", "Hani") == 1
    rows = list(csv.DictReader(open(out, encoding="utf-8")))
    assert [r["relevant"] for r in rows] == ["1", "", "0"]
    assert rows[0]["judge"] == "Yazen+Hani" and rows[1]["judge"] == "DISAGREE Yazen=1 Hani=0"


def test_command_line_prints_markdown(tmp_path, capsys):
    a = write_sheet(tmp_path / "a.csv", {"Q01": [1, 0]})
    b = write_sheet(tmp_path / "b.csv", {"Q01": [1, 0]})
    main([str(a), str(b), "--names", "Yazen,Hani", "--markdown"])
    out = capsys.readouterr().out
    assert "| Q01 query Q01 | 2 | 0.1 | 0.1 | 100% |" in out
    assert "Cohen's kappa: **1.00** (almost perfect)" in out
